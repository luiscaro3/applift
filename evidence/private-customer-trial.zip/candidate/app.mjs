import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';

export class App {
  constructor(filename, provider) {
    this.provider = provider;
    this.db = new DatabaseSync(filename);
    this.db.exec(`PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY,value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS requisitions (id INTEGER PRIMARY KEY,source_id TEXT,subject TEXT NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'new',manual_note TEXT NOT NULL DEFAULT '',completed_at TEXT);
      CREATE TABLE IF NOT EXISTS search_entries (requisition_id INTEGER PRIMARY KEY REFERENCES requisitions(id),content TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS jobs (id INTEGER PRIMARY KEY,payload TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'queued');`);
    this.transaction(() => {
      if (!this.db.prepare('SELECT 1 FROM settings WHERE key=?').get('initialized')) {
        this.db.prepare('INSERT INTO settings VALUES (?,?)').run('mailbox_credential','fixture-grant-founder');
        this.db.prepare('INSERT INTO requisitions VALUES (?,?,?,?,?,?,?)').run(1001,'old-fulfilled','Ship TikTok samples','Send three samples','fulfilled','Customer thanked us','2026-10-18T12:00:00Z');
        this.db.prepare('INSERT INTO requisitions VALUES (?,?,?,?,?,?,?)').run(1002,'old-open','Record campaign clip','Use the autumn campaign brief','new','Keep original footage',null);
        this.db.prepare('INSERT INTO jobs(payload) VALUES (?)').run(JSON.stringify({action:'poll'}));
        this.db.prepare('INSERT INTO settings VALUES (?,?)').run('initialized','yes');
      }
      this.db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY,issuer TEXT NOT NULL,subject TEXT NOT NULL,UNIQUE(issuer,subject));
        CREATE TABLE IF NOT EXISTS connections (id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),provider TEXT NOT NULL,account_id TEXT NOT NULL,credential_reference TEXT,status TEXT NOT NULL,generation INTEGER NOT NULL DEFAULT 1,UNIQUE(provider,account_id));
        CREATE TABLE IF NOT EXISTS consents (state TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),expires INTEGER NOT NULL);`);
      if (!this.db.prepare('SELECT 1 FROM settings WHERE key=?').get('private-v1')) {
        this.db.prepare('INSERT OR IGNORE INTO users(issuer,subject) VALUES (?,?)').run('fixture-auth','founder-subject');
        const founder = this.db.prepare('SELECT id FROM users WHERE issuer=? AND subject=?').get('fixture-auth','founder-subject').id;
        const grant = this.db.prepare('SELECT value FROM settings WHERE key=?').get('mailbox_credential')?.value;
        this.db.prepare('INSERT INTO connections(user_id,provider,account_id,credential_reference,status) VALUES (?,?,?,?,?)').run(founder,'fixture-mail','mailbox-founder',grant ?? null,grant ? 'usable':'reconnect');
        const connection = this.db.prepare('SELECT id FROM connections WHERE user_id=?').get(founder).id;
        this.db.exec('ALTER TABLE requisitions ADD COLUMN connection_id INTEGER REFERENCES connections(id)');
        this.db.prepare('UPDATE requisitions SET connection_id=?').run(connection);
        this.db.exec('ALTER TABLE jobs ADD COLUMN connection_id INTEGER REFERENCES connections(id); ALTER TABLE jobs ADD COLUMN generation INTEGER; ALTER TABLE jobs ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0; ALTER TABLE jobs ADD COLUMN error TEXT;');
        this.db.prepare('UPDATE jobs SET connection_id=?,generation=1').run(connection);
        // Preserve historical duplicate IDs; use the oldest matching source on replay.
        this.db.exec('CREATE INDEX requisition_source ON requisitions(connection_id,source_id)');
        this.db.prepare('DELETE FROM settings WHERE key=?').run('mailbox_credential');
        for (const row of this.db.prepare('SELECT id FROM requisitions').all()) this._index(row.id);
        this.db.prepare('INSERT INTO settings VALUES (?,?)').run('private-v1','yes');
      }
    });
  }
  transaction(fn) { this.db.exec('BEGIN IMMEDIATE'); try { const result=fn(); this.db.exec('COMMIT'); return result; } catch(e) { this.db.exec('ROLLBACK'); throw e; } }
  actor(session) {
    const {issuer,subject}=this.provider.verifySession(session);
    if (!issuer || !subject) throw new Error('Invalid identity');
    this.db.prepare('INSERT OR IGNORE INTO users(issuer,subject) VALUES (?,?)').run(issuer,subject);
    return this.db.prepare('SELECT id FROM users WHERE issuer=? AND subject=?').get(issuer,subject).id;
  }
  signIn(session) { return {user_id:this.actor(session)}; }
  _index(id) { const r=this.db.prepare('SELECT * FROM requisitions WHERE id=?').get(id); this.db.prepare('INSERT OR REPLACE INTO search_entries VALUES (?,?)').run(id,`${r.subject}\n${r.body}`); }
  list(session) { return this.db.prepare('SELECT r.* FROM requisitions r JOIN connections c ON c.id=r.connection_id WHERE c.user_id=? ORDER BY r.id').all(this.actor(session)); }
  get(session,id) { return this.db.prepare('SELECT r.* FROM requisitions r JOIN connections c ON c.id=r.connection_id WHERE c.user_id=? AND r.id=?').get(this.actor(session),id) ?? null; }
  count(session) { return this.db.prepare('SELECT COUNT(*) AS n FROM requisitions r JOIN connections c ON c.id=r.connection_id WHERE c.user_id=?').get(this.actor(session)).n; }
  search(session,text) { return this.db.prepare('SELECT r.* FROM requisitions r JOIN connections c ON c.id=r.connection_id JOIN search_entries s ON s.requisition_id=r.id WHERE c.user_id=? AND s.content LIKE ? ORDER BY r.id').all(this.actor(session),`%${text}%`); }
  update(session,id,patch) {
    const user=this.actor(session);
    return this.transaction(()=>{
      const r=this.db.prepare('SELECT r.* FROM requisitions r JOIN connections c ON c.id=r.connection_id WHERE c.user_id=? AND r.id=?').get(user,id);
      if (!r) throw new Error('Not found');
      const status=patch.status ?? r.status, note=patch.manual_note ?? r.manual_note;
      if (!['new','fulfilled'].includes(status) || typeof note!=='string') throw new Error('Invalid patch');
      this.db.prepare('UPDATE requisitions SET status=?,manual_note=?,completed_at=? WHERE id=?').run(status,note,status==='fulfilled' ? r.completed_at ?? new Date().toISOString():r.completed_at,id);
      return this.db.prepare('SELECT * FROM requisitions WHERE id=?').get(id);
    });
  }
  connections(session) { return this.db.prepare('SELECT id,provider,account_id,status FROM connections WHERE user_id=? ORDER BY id').all(this.actor(session)); }
  beginConnect(session) { const user=this.actor(session), state=randomUUID(); this.db.prepare('INSERT INTO consents VALUES (?,?,?)').run(state,user,Date.now()+600000); return state; }
  completeConnect(session,state,code) {
    const user=this.actor(session);
    return this.transaction(()=>{
      const pending=this.db.prepare('SELECT * FROM consents WHERE state=? AND user_id=? AND expires>?').get(state,user,Date.now());
      if (!pending) throw new Error('Invalid or expired consent state');
      const grant=this.provider.exchangeConsent(code);
      if (!grant.scopes.includes('read-mail')) throw new Error('Missing mail permission');
      const existing=this.db.prepare('SELECT * FROM connections WHERE provider=? AND account_id=?').get(grant.provider,grant.account_id);
      if (existing && existing.user_id!==user) throw new Error('Account already owned');
      if (existing) this.db.prepare("UPDATE connections SET credential_reference=?,status='usable',generation=generation+1 WHERE id=?").run(grant.credential_reference,existing.id);
      else this.db.prepare("INSERT INTO connections(user_id,provider,account_id,credential_reference,status) VALUES (?,?,?,?,'usable')").run(user,grant.provider,grant.account_id,grant.credential_reference);
      this.db.prepare('DELETE FROM consents WHERE state=?').run(state);
      return this.db.prepare('SELECT id,provider,account_id,status FROM connections WHERE provider=? AND account_id=?').get(grant.provider,grant.account_id);
    });
  }
  disconnect(session,id) {
    const user=this.actor(session);
    const reference=this.transaction(()=>{
      const c=this.db.prepare('SELECT * FROM connections WHERE id=? AND user_id=?').get(id,user);
      if (!c) throw new Error('Not found');
      this.db.prepare("UPDATE connections SET status='disconnected',credential_reference=NULL,generation=generation+1 WHERE id=?").run(id);
      this.db.prepare('DELETE FROM consents WHERE user_id=?').run(user);
      return c.credential_reference;
    });
    if (reference) { try { this.provider.revoke(reference); } catch { /* Local disconnect remains authoritative. */ } }
  }
  enqueue(session,id) {
    const user=this.actor(session);
    const c=this.db.prepare("SELECT * FROM connections WHERE id=? AND user_id=? AND status='usable'").get(id,user);
    if (!c) throw new Error('Connection unavailable');
    return Number(this.db.prepare('INSERT INTO jobs(payload,connection_id,generation) VALUES (?,?,?)').run(JSON.stringify({action:'poll'}),c.id,c.generation).lastInsertRowid);
  }
  async poll(session,id) { const job=this.enqueue(session,id); return (await this._run(job)).imported; }
  async runNext({failAfterCommit=false}={}) {
    const job=this.db.prepare("SELECT id FROM jobs WHERE status='queued' ORDER BY id LIMIT 1").get();
    return job ? this._run(job.id,failAfterCommit):null;
  }
  async _run(id,failAfterCommit=false) {
    const job=this.db.prepare("SELECT * FROM jobs WHERE id=? AND status='queued'").get(id);
    if (!job) return null;
    const c=this.db.prepare('SELECT * FROM connections WHERE id=?').get(job.connection_id);
    if (!c || c.status!=='usable' || c.generation!==job.generation) { this.db.prepare("UPDATE jobs SET status='cancelled',error='connection_changed' WHERE id=?").run(id); return {job_id:id,imported:[],status:'cancelled'}; }
    let messages;
    try { messages=await this.provider.fetchMessages(c.credential_reference); }
    catch(e) {
      this.transaction(()=>{
        if (e.code==='invalid_grant') this.db.prepare("UPDATE connections SET status='reconnect',generation=generation+1 WHERE id=? AND generation=? AND status='usable'").run(c.id,c.generation);
        const status=e.code==='temporarily_unavailable' && job.attempts<2 ? 'queued': 'failed';
        this.db.prepare('UPDATE jobs SET attempts=attempts+1,status=?,error=? WHERE id=?').run(status,['invalid_grant','temporarily_unavailable'].includes(e.code) ? e.code:'provider_error',id);
      });
      throw new Error(e.code==='invalid_grant' ? 'Reconnection required':'Mailbox fetch failed');
    }
    const imported=this.transaction(()=>{
      const current=this.db.prepare('SELECT * FROM connections WHERE id=?').get(c.id);
      if (current.status!=='usable' || current.generation!==c.generation) { this.db.prepare("UPDATE jobs SET status='cancelled',error='connection_changed' WHERE id=?").run(id); return []; }
      const ids=[];
      for (const m of messages) {
        if (typeof m.id!=='string'||typeof m.subject!=='string'||typeof m.body!=='string') throw new Error('Invalid message');
        let r=this.db.prepare('SELECT id FROM requisitions WHERE connection_id=? AND source_id=? ORDER BY id LIMIT 1').get(c.id,m.id);
        if (r) this.db.prepare('UPDATE requisitions SET subject=?,body=? WHERE id=?').run(m.subject,m.body,r.id);
        else r={id:Number(this.db.prepare('INSERT INTO requisitions(connection_id,source_id,subject,body) VALUES (?,?,?,?)').run(c.id,m.id,m.subject,m.body).lastInsertRowid)};
        this._index(r.id); ids.push(r.id);
      }
      return ids;
    });
    if (failAfterCommit) throw new Error('Simulated interrupted acknowledgement');
    this.db.prepare("UPDATE jobs SET status='done',error=NULL WHERE id=? AND status='queued'").run(id);
    return {job_id:id,imported};
  }
  close() { this.db.close(); }
}
