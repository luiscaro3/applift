import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { App } from './app.mjs';
import { ProviderSimulator } from './provider-simulator.mjs';

test('personal POC retains its existing campaign workflow', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'applift-baseline-'));
  const app = new App(join(dir, 'app.sqlite'), new ProviderSimulator());
  try {
    assert.equal(app.count('fixture-session-founder'), 2);
    assert.equal(app.get('fixture-session-founder',1001).status, 'fulfilled');
    assert.equal(app.get('fixture-session-founder',1001).manual_note, 'Customer thanked us');
    assert.equal(app.search('fixture-session-founder','TikTok').length, 1);
    app.update('fixture-session-founder',1002, { status: 'fulfilled' });
    assert.ok(app.get('fixture-session-founder',1002).completed_at);
    const result = await app.runNext();
    assert.equal(result.imported.length, 1);
    assert.equal(app.search('fixture-session-founder','Founder campaign').length, 1);
  } finally { app.close(); rmSync(dir, { recursive: true, force: true }); }
});

