import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {App} from './app.mjs';
import {ProviderSimulator} from './provider-simulator.mjs';
const F='fixture-session-founder', C='fixture-session-customer', T='fixture-session-third';
function fixture(fn) { return async()=>{const dir=mkdtempSync(join(tmpdir(),'private-campaign-')), p=new ProviderSimulator(), file=join(dir,'app.sqlite'), app=new App(file,p); try {await fn(app,p,file);} finally {app.close();rmSync(dir,{recursive:true,force:true});}}; }
function connect(a,s,code) {return a.completeConnect(s,a.beginConnect(s),code).id;}
test('all private service paths enforce verified actor and stable identities',fixture(async(a)=>{
  assert.equal(a.count(C),0); assert.equal(a.count(F),2);
  assert.deepEqual(a.signIn(C),a.signIn(C));
  assert.equal(a.get(C,1001),null); assert.deepEqual(a.search(C,'TikTok'),[]);
  assert.throws(()=>a.update(C,1001,{manual_note:'stolen'}),/Not found/);
  for(const call of [()=>a.list(),()=>a.get('forged',1001),()=>a.count('forged'),()=>a.search('forged',''),()=>a.update('forged',1001,{}),()=>a.connections('forged'),()=>a.beginConnect('forged'),()=>a.enqueue(C,1),()=>a.disconnect(C,1)]) assert.throws(call);
  const customer=connect(a,C,'fixture-consent-customer');
  await a.poll(C,customer); await a.poll(F,1);
  assert.equal(a.count(C),1); assert.equal(a.count(F),3);
  assert.equal(a.list(C)[0].subject,'Customer campaign'); assert.equal(a.search(F,'Customer').length,0);
  assert.throws(()=>connect(a,T,'fixture-consent-customer'),/already owned/);
  assert.throws(()=>a.completeConnect(T,a.beginConnect(C),'fixture-consent-third'),/consent state/);
  assert.equal(JSON.stringify(a.connections(C)).includes('credential'),false);
}));
test('replay and interrupted acknowledgement retain completed work, notes, source IDs and index',fixture(async(a,p)=>{
  p.setMessages('mailbox-founder',[{id:'old-fulfilled',subject:'Updated source',body:'new facts'}]);
  await assert.rejects(a.runNext({failAfterCommit:true}),/acknowledgement/);
  const repeat=await a.runNext(); assert.deepEqual(repeat.imported,[1001]); assert.equal(a.count(F),2);
  assert.equal(a.get(F,1001).manual_note,'Customer thanked us'); assert.equal(a.get(F,1001).completed_at,'2026-10-18T12:00:00Z'); assert.equal(a.get(F,1001).status,'fulfilled');
  assert.equal(a.search(F,'Updated source')[0].id,1001); assert.equal(a.search(F,'TikTok').length,0);
  await a.poll(F,1); assert.equal(a.count(F),2);
}));
test('disconnect cancels in-flight and queued work and stale consent; same account reconnect preserves history',fixture(async(a,p)=>{
  const id=connect(a,C,'fixture-consent-customer'); await a.poll(C,id);
  const r=a.list(C)[0]; a.update(C,r.id,{status:'fulfilled',manual_note:'Retain me'});
  const state=a.beginConnect(C); a.enqueue(C,id);
  p.setMessages('mailbox-customer',[{id:'late',subject:'Late',body:'Must not commit'}]);
  p.beforeReturn=()=>a.disconnect(C,id);
  const result=await a.poll(C,id); assert.deepEqual(result,[]); assert.equal(a.count(C),1);
  assert.throws(()=>a.completeConnect(C,state,'fixture-consent-customer'),/consent state/);
  assert.equal((await a.runNext()).job_id,1); // founder legacy work continues
  assert.equal((await a.runNext()).status,'cancelled');
  // Simulator has a new approved grant for the same stable mailbox.
  p.grants.set('fixture-grant-customer-new',{account_id:'mailbox-customer',usable:true}); p.consent.set('fixture-consent-customer-new','fixture-grant-customer-new');
  assert.equal(connect(a,C,'fixture-consent-customer-new'),id);
  p.setMessages('mailbox-customer',[{id:'fresh-message',subject:'Changed source',body:'Changed'}]);
  await a.poll(C,id); assert.equal(a.count(C),1); assert.equal(a.get(C,r.id).manual_note,'Retain me'); assert.equal(a.get(C,r.id).status,'fulfilled');
}));
test('grant failure and bounded temporary retries affect only their connection',fixture(async(a,p)=>{
  const id=connect(a,C,'fixture-consent-customer'); p.revoke('fixture-grant-customer');
  await assert.rejects(a.poll(C,id),/Reconnection/); assert.equal(a.connections(C)[0].status,'reconnect');
  await a.runNext(); assert.equal(a.count(F),3);
  p.temporaryFailures.add('fixture-grant-founder'); const job=a.enqueue(F,1);
  for(let i=0;i<3;i++) await assert.rejects(a.runNext(),/fetch failed/);
  const stored=a.db.prepare('SELECT * FROM jobs WHERE id=?').get(job); assert.equal(stored.status,'failed'); assert.equal(stored.attempts,3); assert.equal(a.connections(F)[0].status,'usable');
  p.temporaryFailures.clear(); await a.poll(F,1); assert.equal(a.count(F),3);
}));
test('reopen retains users, consent consumption, connection and imported progress',fixture(async(a,p,file)=>{
  const id=connect(a,C,'fixture-consent-customer'); await a.poll(C,id); const row=a.list(C)[0]; a.update(C,row.id,{manual_note:'persisted'});
  const b=new App(file,p); try {assert.equal(b.get(C,row.id).manual_note,'persisted'); assert.equal(b.count(F),2); assert.equal(b.connections(C)[0].id,id);} finally {b.close();}
}));
test('existing legacy database migrates IDs, grant, index, progress and queued poll atomically',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'legacy-campaign-')), file=join(dir,'app.sqlite'); let a;
  try {
    const d=new DatabaseSync(file); d.exec(`CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL); INSERT INTO settings VALUES('initialized','yes'),('mailbox_credential','fixture-grant-founder'); CREATE TABLE requisitions(id INTEGER PRIMARY KEY,source_id TEXT,subject TEXT NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'new',manual_note TEXT NOT NULL DEFAULT '',completed_at TEXT); INSERT INTO requisitions VALUES(1001,'old-fulfilled','Original','Body','fulfilled','Historical note','2026-01-01'); CREATE TABLE search_entries(requisition_id INTEGER PRIMARY KEY REFERENCES requisitions(id),content TEXT NOT NULL); INSERT INTO search_entries VALUES(1001,'Original'); CREATE TABLE jobs(id INTEGER PRIMARY KEY,payload TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'queued'); INSERT INTO jobs VALUES(47,'{"action":"poll"}','queued');`); d.close();
    a=new App(file,new ProviderSimulator()); assert.equal(a.count(C),0); assert.equal(a.get(F,1001).manual_note,'Historical note'); assert.equal(a.get(F,1001).completed_at,'2026-01-01'); assert.equal(a.search(F,'Original')[0].id,1001); assert.equal((await a.runNext()).job_id,47);
    assert.equal(a.db.prepare("SELECT * FROM settings WHERE key='mailbox_credential'").get(),undefined);
  } finally {a?.close();rmSync(dir,{recursive:true,force:true});}
});
