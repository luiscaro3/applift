# Independent implementation trial result

## Outcome and scope

Implemented and executed a private customer backend in this frozen representative fixture. No prior conversation, sibling trial artifacts, evaluation files, author research or baseline directory were consulted. Used the supplied public AppLift skill and selected identity, ownership, connections and background-work contracts. No skill-package or provider-simulator edits, dependencies, live providers, credentials, network listeners, payment, deployment or publication.

This is evidence for this tested SQLite fixture only. It does not establish reduced effort, organic discovery, broad compatibility or production readiness.

## Host mappings: observed -> implemented

- Observed: no local user or auth guard; every operation was global. Added a native `users` mapping unique by provider-verified `(issuer,subject)`. The supplied verifier remains session authority; no local tokens/session store. Customer-facing service operations verify every call and derive ownership, rather than accepting an owner ID.
- Observed: existing requisitions, IDs 1001/1002, lifecycle fields, search table and jobs. Reused all tables/IDs. Added only a connection relationship to requisitions and queue entries. Reads, details, writes, search and counts join that connection's owner inside SQL. No team, role, duplicated owner field or search authorization layer.
- Observed: global `settings.mailbox_credential` and unscoped pending poll. Migration atomically assigns historical records, search and jobs to the README-proven founder (`fixture-auth`, `founder-subject`), before any signup; moves the grant reference to the founder's connection and removes the global credential setting. Existing persisted databases and fresh initialization are tested. Historical duplicate source records, if present, retain their IDs; future replay selects the oldest matching source rather than deleting history.
- Missing relationship: customer -> external account -> grant reference. Added connections with unique `(provider,account_id)`, derived owner and local usable/reconnect/disconnected state. The provider returns account ID/scopes/grant reference. Service responses omit grant references. Retaining references in this local SQLite fixture is not a real secret-store implementation.
- Missing retained consent facts: one-use random state, verified actor, expiry. Added `consents`. Disconnect invalidates that actor's pending callbacks. Same-account reconnect increments the existing connection generation; new accounts get separate records. A different owner cannot take an already associated account.
- Observed: queued payload carried no authority and acknowledgement could be lost. Reused jobs, adding connection/generation/attempts/error so workers select current credentials and current ownership. Recheck generation/usability in a SQLite write transaction after fetch and before import; no database transaction spans fetch. Generation is required to reject delayed results after disconnect/reconnect. Old queued generations cancel. Temporary errors have three total fetch attempts, invalid grants put only the affected connection into reconnection state.
- Observed: imports always inserted and lifecycle fields shared the same row. Imports now match `(connection_id,source_id)` in a native transaction and update only subject/body. Source IDs are namespaced by connection, so two mailboxes' identical source IDs do not collide. Status, notes, completion timestamp and business ID survive replay; search updates with source facts in the same transaction. Lost acknowledgement safely replays. This promises convergent database imports, not exactly-once execution.

## Changed paths

- `app.mjs`: actual migration, authentication/authorization, connections/consent, scoped operations, queue recovery and transactional import.
- `baseline.test.mjs`: same business scenario with explicit founder session arguments for the changed service boundary.
- `private.test.mjs`: six integration checks covering private customer transition and recovery.
- `README.md`: service API example, trust boundary and retry/reconnection semantics.
- `TRIAL-RESULT.md`: this report.

The supplied public skill package and `provider-simulator.mjs` remain untouched.

## Executed evidence

`node --test`: 7 tests passed, 0 failures. Actual execution used SQLite files in temporary directories; no external calls.

Checks include:

1. Original personal campaign workflow retains IDs, fulfillment, note, search and queued import.
2. New signup starts empty even before founder signs in; repeat identity maps to one user. Invalid sessions and cross-owner detail/write/enqueue/disconnect fail; scoped list/search/count isolate two mailbox imports with the same source ID; consent cannot transfer a mailbox or cross actors; returned connection metadata has no grant reference.
3. Historical fulfilled source replay and simulated post-commit lost acknowledgement keep the original business ID, status, completion and note, and refresh the search index without duplicates.
4. Disconnect during fetch rejects late data, cancels queued old-generation work, rejects a pending old callback, allows founder work to continue, and same-account reconnection retains manually completed customer work.
5. Invalid grant requires reconnection only for that connection; three temporary failures exhaust a job while keeping the connection usable; a later new attempt succeeds.
6. Opening a second App on the same file retains customer, connection and note data.
7. Constructing an actual pre-transition schema/data file proves migration preserves historical progress, source/search identity and existing queued job ID and removes the global credential setting.

## Service entry points and exercising

See the executable-style example in README. Customer API: `signIn(session)`, `list(session)`, `get(session,id)`, `count(session)`, `search(session,text)`, `update(session,id,patch)`, `connections(session)`, `beginConnect(session)`, `completeConnect(session,state,code)`, `disconnect(session,connectionId)`, `enqueue(session,connectionId)`, `poll(session,connectionId)`.

`runNext(options)` is a trusted worker entry, not customer accessible; it derives authority from persisted jobs/connections. Other object internals/database access must remain trusted server facilities. The app has no router or browser UI to expose them. `close()` ends the local connection.

## Business clarifications versus engineering rescue

No new business question was needed: README supplies private ownership, proven founder identity, new customers starting empty, same-mailbox reconnect, and progress preservation. No author engineering rescue was requested or received. Engineering choices made independently: connection-derived ownership, local SQL migration, actor-bound consent state, generation checks, retained queue attempts, separate connections for a different mailbox, exclusive mailbox ownership and targeted source-field updates.

## Proposed/unresolved outside executed scope

All above host mappings are implemented, not merely proposed. Live provider mechanisms remain unresolved/unrun: actual SDK/issuer configuration, credential storage/refresh, approved consent and redirect routes, browser state/PKCE/nonce, real revocation, logout/account recovery, provider scope/account verification and production operator setup. The simulator supplies the verified identities, account claims and grant references directly, so no external provider documentation was needed to implement those fixed local methods; this is not evidence of live OAuth integration.

No UI exists; session errors throw and connection state is available to a future UI. The provider verifier owns session validity; session expiry/logout behavior was not simulated beyond invalid-session rejection. Remote revocation cleanup is best effort after durable local disable; failed remote cleanup is not durably retried. Jobs can be retried sequentially; there is no distributed worker lease/fairness guarantee. Concurrent replay is serialized by SQLite transactions, but no multi-process stress or power-loss test ran. Historical duplicate source rows are retained rather than automatically consolidated. Source events have no provider timestamp/revision, so overlapping successful fetches from the same unchanged connection have no source-order conflict guarantee. Fresh schema bootstrapping uses fixture-only founder account/grant details supplied by README; adapting migration to another host requires proof of its original owner/account. No live-provider acceptance, general compatibility or security audit is claimed.
