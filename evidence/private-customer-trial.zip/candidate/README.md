# Personal campaign app: frozen starting point

This is a small representative backend fixture, not an actual customer's production app. It uses Node 24's built-in SQLite and no dependencies. `node --test` runs the existing personal workflow check. No UI is included.

`App(filename, provider)` initializes a personal database if empty. It currently lists, searches and updates requisitions, polls one configured mailbox and queues/runs imports. Seed record 1001 is fulfilled; 1002 is still open. Imported message fields and manually managed fulfillment fields live in the same existing record. This is a single-user POC: it has no authentication or customer separation yet.

The included provider simulator documents the local boundary used by the trial. `verifySession` returns a verified identity for a fixture session; `exchangeConsent` returns an external account and credential reference; `fetchMessages` fetches that grant's mailbox. Error codes distinguish invalid session, invalid consent, invalid grant and temporary failure. Values beginning `fixture-` are public test data, not credentials. `revoke`, `setMessages`, `beforeReturn` and `temporaryFailures` let tests simulate provider changes and interruptions. Do not change the simulator to make application tests pass.

The founder's proven identity for this isolated business setup is issuer `fixture-auth`, subject `founder-subject`. The original mailbox and existing data belong to that founder, not the first new signup. Customers do not share work. New customers start empty, use their own mailbox, can disconnect it and reconnect the same mailbox later. Fulfillment status, completion time and manual notes must remain when source emails are imported again. No subscription or pricing change is requested in this trial.

The implementation may change the app's service API as needed; document the resulting entry points. Preserve the existing business behavior, IDs and records. Implement and verify the transition using the supplied public AppLift kit and normal provider references. No live login, credential creation, network service exposure, paid API or deployment is authorized. Report exactly what was simulated and what actually executed.

## Implemented private service API

Run `node --test` on Node 24. The API is an in-process backend service, with the fixed local provider simulator; no HTTP server or UI is created.

```js
import { App } from './app.mjs';
import { ProviderSimulator } from './provider-simulator.mjs';
const app = new App('campaign.sqlite', new ProviderSimulator());
const session = 'fixture-session-customer';
app.signIn(session); // resolves the provider's verified issuer + subject
const state = app.beginConnect(session);
const connection = app.completeConnect(session, state, 'fixture-consent-customer');
await app.poll(session, connection.id);
const records = app.list(session);
app.update(session, records[0].id, { status: 'fulfilled', manual_note: 'Samples delivered' });
app.search(session, 'campaign');
app.count(session);
app.get(session, records[0].id);
app.connections(session); // no credential references
app.enqueue(session, connection.id);
await app.runNext(); // trusted scheduler/worker only, no browser route
app.disconnect(session, connection.id);
app.close();
```

All customer-facing methods require a provider-verifiable session. Old calls without a session intentionally fail. `poll` requires a connection ID. The existing personal test now supplies the founder's session. `runNext({failAfterCommit:true})` simulates lost acknowledgement after an import commit; rerunning safely finds the same records.

Keep `db`, `provider`, `transaction`, `_index`, `_run`, constructor and `runNext` within trusted server code. They are internal implementation/worker facilities, not a remotely exposed API. Callers must never receive the App instance, database handle, provider object or arbitrary worker invocation. Session verification is delegated to the supplied provider. A live provider adapter, OAuth callback routes and its state/PKCE/nonce/configuration are outside this local trial.

`connections` returns IDs, stable external account identity and local usability only. Consent states are actor-bound, single-use, expire after ten minutes and are invalidated on disconnect. A different mailbox creates a separate connection and keeps earlier records under their original connection. One mailbox cannot be claimed by a different customer, including after disconnect. Reconnecting the same mailbox retains its connection ID. Local disconnect commits before best-effort simulator revocation. Temporary fetch failures retry up to three attempts per queued job; after that, enqueue a fresh attempt. Invalid grants require consent again. A manual `poll` also leaves a durable job, so it can be resumed by `runNext` after a temporary failure.
