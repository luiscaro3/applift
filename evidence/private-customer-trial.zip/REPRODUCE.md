# Reproduce the bounded private-customer fixture result

This archive is optional evaluation evidence, not an AppLift runtime, application starter or production integration. It includes the original personal backend, independent agent's submitted implementation, its checks and the evaluator's separately authored checks. No dependencies, database snapshot, credential or live provider are included.

Use Node v24.19.0 (the tested runtime) and its built-in SQLite. In the extracted directory:

```sh
node --test baseline/baseline.test.mjs
node --test candidate/baseline.test.mjs candidate/private.test.mjs evaluation.test.mjs
```

The first command exercises the original personal behavior; the second exercises the submitted implementation and held-out evaluation. SQLite files are created in temporary directories and removed by the tests. There is no network listener or provider call.

## Original attempt

The frozen baseline was committed as `7426ecfab243ba8e856639289b1931fa213af256` locally. The available public AppLift kit was revision `c6154de4fc901ac4d4f173c8f368923221a53ddb`. Its skill was copied into candidate-local `.agents/skills/applift-specs` and explicitly requested by path. That copy is omitted here to avoid duplicating the product; retrieve that public revision if examining the exact instructions supplied. Package selection/reference checks passed, but automatic skill activation was not tested.

Fresh agent request:

> My campaign app works for me. Let other customers sign in and use it privately with their own mailbox, without seeing my information. Keep our completed work and notes, including when an email is processed again. Please implement it.

The agent had no inherited author conversation. It was allowed to inspect only the candidate and supplied public kit, applicable governing constraints and ordinary official provider docs. EVALUATION.md was written before dispatch and withheld; the concrete evaluator was written after submission against those fixed requirements and the documented service API. Business choices and fixed simulator interfaces were supplied in the baseline README. The agent reported it needed no additional business clarification or provider docs for those local methods. No engineering correction was supplied by the author.

The provider simulator was not modified. Simulated verified identities, consent/grant results and mailbox replies are not real OAuth acceptance. Real token refresh/logout, credential protection, provider approval, UI/HTTP access and distributed-worker behavior were not demonstrated.

To repeat an agent attempt, copy baseline into a new isolated candidate, supply the pinned public skill and the ordinary request, and withhold evaluator artifacts until submission. A repeat is a new experiment, not a required step for using AppLift. Adapt only the evaluator's API calls if the new candidate chooses a different interface; preserve its predeclared behavior requirements.

## Interpretation

Sixteen checks passed: seven implementer checks and nine held-out evaluator scenarios. The original standalone baseline check also passed before changes. No failed implementation was repaired after evaluator feedback. This is one author-created representative fixture and one explicitly supplied-kit attempt, not a comparative effort study, organically discovered adoption, actual customer app or compatibility certification. Source-event ordering beyond this simulator and live-provider workflows remain outside its evidence.

ACCEPTANCE.tap records the combined executed result. PROTOCOL.md and EVALUATION.md describe the claim boundary and predetermined requirements. Candidate/TRIAL-RESULT.md is the implementer's report, not a substitute for the executable checks. The MIT license covers the supplied evaluation sources.
