import { DatabaseSync } from 'node:sqlite';

export class App {
  constructor(filename, provider) {
    this.provider = provider;
    this.db = new DatabaseSync(filename);
    this.db.exec(`
      PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS requisitions (
        id INTEGER PRIMARY KEY, source_id TEXT, subject TEXT NOT NULL, body TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'new', manual_note TEXT NOT NULL DEFAULT '', completed_at TEXT
      );
      CREATE TABLE IF NOT EXISTS search_entries (
        requisition_id INTEGER PRIMARY KEY REFERENCES requisitions(id), content TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY, payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued'
      );
    `);
    if (!this.db.prepare('SELECT value FROM settings WHERE key=?').get('initialized')) {
      this.db.prepare('INSERT INTO settings VALUES (?,?)').run('mailbox_credential', 'fixture-grant-founder');
      this.db.prepare('INSERT INTO requisitions VALUES (?,?,?,?,?,?,?)').run(1001, 'old-fulfilled', 'Ship TikTok samples', 'Send three samples', 'fulfilled', 'Customer thanked us', '2026-10-18T12:00:00Z');
      this.db.prepare('INSERT INTO requisitions VALUES (?,?,?,?,?,?,?)').run(1002, 'old-open', 'Record campaign clip', 'Use the autumn campaign brief', 'new', 'Keep original footage', null);
      for (const row of this.db.prepare('SELECT * FROM requisitions').all()) this.index(row.id);
      this.db.prepare('INSERT INTO jobs(payload) VALUES (?)').run(JSON.stringify({ action: 'poll' }));
      this.db.prepare('INSERT INTO settings VALUES (?,?)').run('initialized', 'yes');
    }
  }

  index(id) {
    const row = this.db.prepare('SELECT * FROM requisitions WHERE id=?').get(id);
    this.db.prepare('INSERT OR REPLACE INTO search_entries VALUES (?,?)').run(id, `${row.subject}\n${row.body}`);
  }

  list() { return this.db.prepare('SELECT * FROM requisitions ORDER BY id').all(); }
  get(id) { return this.db.prepare('SELECT * FROM requisitions WHERE id=?').get(id) ?? null; }
  count() { return this.db.prepare('SELECT COUNT(*) AS count FROM requisitions').get().count; }
  search(text) {
    return this.db.prepare('SELECT r.* FROM requisitions r JOIN search_entries s ON s.requisition_id=r.id WHERE s.content LIKE ? ORDER BY r.id').all(`%${text}%`);
  }

  update(id, patch) {
    const row = this.get(id);
    if (!row) throw new Error('Not found');
    const status = patch.status ?? row.status;
    const note = patch.manual_note ?? row.manual_note;
    const completed = status === 'fulfilled' ? (row.completed_at ?? new Date().toISOString()) : row.completed_at;
    this.db.prepare('UPDATE requisitions SET status=?, manual_note=?, completed_at=? WHERE id=?').run(status, note, completed, id);
    return this.get(id);
  }

  async poll() {
    const credential = this.db.prepare('SELECT value FROM settings WHERE key=?').get('mailbox_credential').value;
    const messages = await this.provider.fetchMessages(credential);
    const imported = [];
    for (const message of messages) {
      const result = this.db.prepare('INSERT INTO requisitions(source_id,subject,body) VALUES (?,?,?)').run(message.id, message.subject, message.body);
      const id = Number(result.lastInsertRowid);
      this.index(id);
      imported.push(id);
    }
    return imported;
  }

  enqueue() { return Number(this.db.prepare('INSERT INTO jobs(payload) VALUES (?)').run(JSON.stringify({ action: 'poll' })).lastInsertRowid); }

  async runNext({ failAfterCommit = false } = {}) {
    const job = this.db.prepare("SELECT * FROM jobs WHERE status='queued' ORDER BY id LIMIT 1").get();
    if (!job) return null;
    const imported = await this.poll();
    if (failAfterCommit) throw new Error('Simulated interrupted acknowledgement');
    this.db.prepare("UPDATE jobs SET status='done' WHERE id=?").run(job.id);
    return { job_id: job.id, imported };
  }

  close() { this.db.close(); }
}
