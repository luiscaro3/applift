// Local test doubles, not real sessions, credentials, OAuth or mailbox API calls.
export class ProviderSimulator {
  constructor() {
    this.sessions = new Map([
      ['fixture-session-founder', { issuer: 'fixture-auth', subject: 'founder-subject' }],
      ['fixture-session-customer', { issuer: 'fixture-auth', subject: 'customer-subject' }],
      ['fixture-session-third', { issuer: 'fixture-auth', subject: 'third-subject' }],
    ]);
    this.grants = new Map([
      ['fixture-grant-founder', { account_id: 'mailbox-founder', usable: true }],
      ['fixture-grant-founder-new', { account_id: 'mailbox-founder', usable: true }],
      ['fixture-grant-customer', { account_id: 'mailbox-customer', usable: true }],
      ['fixture-grant-third', { account_id: 'mailbox-third', usable: true }],
    ]);
    this.consent = new Map([
      ['fixture-consent-founder', 'fixture-grant-founder'],
      ['fixture-consent-founder-new', 'fixture-grant-founder-new'],
      ['fixture-consent-customer', 'fixture-grant-customer'],
      ['fixture-consent-third', 'fixture-grant-third'],
    ]);
    this.mailboxes = new Map([
      ['mailbox-founder', [{ id: 'fresh-message', subject: 'Founder campaign', body: 'Founder private brief' }]],
      ['mailbox-customer', [{ id: 'fresh-message', subject: 'Customer campaign', body: 'Customer private brief' }]],
      ['mailbox-third', [{ id: 'third-message', subject: 'Third campaign', body: 'Third private brief' }]],
    ]);
    this.fetches = [];
    this.beforeReturn = null;
    this.temporaryFailures = new Set();
  }

  verifySession(session) {
    const identity = this.sessions.get(session);
    if (!identity) throw Object.assign(new Error('Invalid session'), { code: 'unauthenticated' });
    return { ...identity };
  }

  exchangeConsent(code) {
    const credential_reference = this.consent.get(code);
    const grant = this.grants.get(credential_reference);
    if (!grant) throw Object.assign(new Error('Invalid consent code'), { code: 'invalid_consent' });
    return { provider: 'fixture-mail', account_id: grant.account_id, credential_reference, scopes: ['read-mail'] };
  }

  async fetchMessages(credentialReference) {
    this.fetches.push(credentialReference);
    const grant = this.grants.get(credentialReference);
    if (!grant?.usable) throw Object.assign(new Error('Reconnection required'), { code: 'invalid_grant' });
    if (this.temporaryFailures.has(credentialReference)) throw Object.assign(new Error('Temporary provider failure'), { code: 'temporarily_unavailable' });
    const result = structuredClone(this.mailboxes.get(grant.account_id) ?? []);
    if (this.beforeReturn) { const hook = this.beforeReturn; this.beforeReturn = null; await hook(); }
    return result;
  }

  revoke(credentialReference) { const grant = this.grants.get(credentialReference); if (grant) grant.usable = false; }
  setMessages(accountId, messages) { this.mailboxes.set(accountId, structuredClone(messages)); }
}
