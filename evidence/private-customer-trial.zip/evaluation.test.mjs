import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, rmSync, readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {App} from './candidate/app.mjs';
import {App as BaselineApp} from './baseline/app.mjs';
import {ProviderSimulator} from './candidate/provider-simulator.mjs';

const F='fixture-session-founder', C='fixture-session-customer', T='fixture-session-third';
const connect=(a,s,code)=>a.completeConnect(s,a.beginConnect(s),code).id;
const ownConnection=(a,s)=>a.connections(s)[0].id;
function scenario(fn) {return async()=>{
  const dir=mkdtempSync(join(tmpdir(),'applift-independent-evaluation-'));
  const provider=new ProviderSimulator(), app=new App(join(dir,'campaign.sqlite'),provider);
  try {await app.runNext(); await fn(app,provider,join(dir,'campaign.sqlite'));}
  finally {app.close(); rmSync(dir,{recursive:true,force:true});}
};}

test('held-out: actual frozen baseline database migrates before unrelated first signup',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'applift-real-baseline-')), file=join(dir,'campaign.sqlite'), p=new ProviderSimulator();
  let current;
  try {
    const old=new BaselineApp(file,p), before=old.list().map(r=>({...r})); old.close();
    current=new App(file,p);
    assert.equal(current.count(T),0);
    assert.equal(current.count(F),before.length);
    for(const oldRecord of before){const now=current.get(F,oldRecord.id); for(const [key,value] of Object.entries(oldRecord))assert.equal(now[key],value,key);}
    assert.equal(current.db.prepare("SELECT value FROM settings WHERE key='mailbox_credential'").get(),undefined);
    assert.equal((await current.runNext()).job_id,1);
    assert.equal(current.search(T,'Founder').length,0);
    assert.equal(current.search(F,'Founder').length,1);
  } finally {current?.close(); rmSync(dir,{recursive:true,force:true});}
});

test('held-out: invalid sessions and all customer record operations fail closed',scenario(async(a,p)=>{
  const cid=connect(a,C,'fixture-consent-customer'); await a.poll(C,cid);
  const customerRecord=a.list(C)[0], founderId=a.list(F)[0].id;
  assert.equal(a.get(C,founderId),null); assert.equal(a.get(F,customerRecord.id),null);
  assert.equal(a.search(C,'Founder private').length,0); assert.equal(a.search(F,'Customer private').length,0);
  assert.equal(a.count(C),1); assert.equal(a.list(C).length,1);
  assert.throws(()=>a.update(C,founderId,{status:'fulfilled',manual_note:'unauthorized'}));
  for(const fn of [()=>a.signIn('altered'),()=>a.list('altered'),()=>a.get('altered',founderId),()=>a.count('altered'),()=>a.search('altered',''),()=>a.update('altered',customerRecord.id,{}),()=>a.beginConnect('altered'),()=>a.connections('altered')])assert.throws(fn);
  const own=a.signIn(C); assert.deepEqual(a.signIn(C),own);
  a.update(C,customerRecord.id,{owner_id:a.signIn(F).user_id,connection_id:ownConnection(a,F),status:'fulfilled'});
  assert.equal(a.get(F,customerRecord.id),null); assert.equal(a.get(C,customerRecord.id).status,'fulfilled');
}));

test('held-out: same source ID in different accounts never merges and search follows owner',scenario(async(a,p)=>{
  const cid=connect(a,C,'fixture-consent-customer'); const [customerId]=await a.poll(C,cid);
  const fid=ownConnection(a,F), [founderId]=await a.poll(F,fid);
  assert.notEqual(customerId,founderId);
  assert.equal(a.get(C,customerId).source_id,a.get(F,founderId).source_id);
  assert.equal(a.get(C,founderId),null); assert.equal(a.get(F,customerId),null);
  const before=a.count(C); for(let n=0;n<3;n++)assert.deepEqual(await a.poll(C,cid),[customerId]);
  assert.equal(a.count(C),before);
  assert.equal(a.search(C,'Founder').length,0);
}));

test('held-out: source replay updates imported facts but preserves founder and customer progress',scenario(async(a,p)=>{
  const fid=ownConnection(a,F), before=a.get(F,1001);
  p.setMessages('mailbox-founder',[{id:'old-fulfilled',subject:'Revised founder source',body:'Fresh source facts'}]);
  assert.deepEqual(await a.poll(F,fid),[1001]);
  const after=a.get(F,1001);
  for(const key of ['id','source_id','status','manual_note','completed_at'])assert.equal(after[key],before[key]);
  assert.equal(after.subject,'Revised founder source'); assert.equal(a.search(F,'Revised founder')[0].id,1001);
  const cid=connect(a,C,'fixture-consent-customer'),[rid]=await a.poll(C,cid);
  a.update(C,rid,{status:'fulfilled',manual_note:'Delivered manually'}); const completed=a.get(C,rid).completed_at;
  p.setMessages('mailbox-customer',[{id:'fresh-message',subject:'Revised customer source',body:'Updated request text'}]);
  await a.poll(C,cid); await a.poll(C,cid);
  assert.equal(a.count(C),1); const r=a.get(C,rid); assert.equal(r.status,'fulfilled'); assert.equal(r.manual_note,'Delivered manually'); assert.equal(r.completed_at,completed);
}));

test('held-out: post-commit acknowledgement loss cannot duplicate or undo intervening user progress',scenario(async(a,p)=>{
  const cid=connect(a,C,'fixture-consent-customer'); a.enqueue(C,cid);
  await assert.rejects(a.runNext({failAfterCommit:true}),/acknowledgement/);
  const [r]=a.list(C); a.update(C,r.id,{status:'fulfilled',manual_note:'Fulfilled after import commit'});
  const completed=a.get(C,r.id).completed_at;
  p.setMessages('mailbox-customer',[{id:r.source_id,subject:'Replay after acknowledgement loss',body:'Replayed body'}]);
  const retry=await a.runNext(); assert.deepEqual(retry.imported,[r.id]);
  assert.equal(a.count(C),1); const after=a.get(C,r.id); assert.equal(after.status,'fulfilled'); assert.equal(after.manual_note,'Fulfilled after import commit'); assert.equal(after.completed_at,completed);
}));

test('held-out: disconnect plus same-account reconnect invalidates the old in-flight result',scenario(async(a,p)=>{
  const cid=connect(a,C,'fixture-consent-customer'), staleState=a.beginConnect(C);
  p.beforeReturn=()=>{
    a.disconnect(C,cid);
    p.grants.set('fixture-grant-customer-renewed',{account_id:'mailbox-customer',usable:true});
    p.consent.set('fixture-consent-customer-renewed','fixture-grant-customer-renewed');
    assert.equal(connect(a,C,'fixture-consent-customer-renewed'),cid);
  };
  assert.deepEqual(await a.poll(C,cid),[]); assert.equal(a.count(C),0);
  assert.throws(()=>a.completeConnect(C,staleState,'fixture-consent-customer-renewed'));
  assert.equal((await a.poll(C,cid)).length,1);
  assert.equal((await a.poll(F,ownConnection(a,F))).length,1);
}));

test('held-out: cross-owner connection calls denied and a different account does not relabel history',scenario(async(a,p)=>{
  const cid=connect(a,C,'fixture-consent-customer'), [rid]=await a.poll(C,cid);
  a.update(C,rid,{status:'fulfilled',manual_note:'Original account history'});
  assert.throws(()=>a.disconnect(T,cid)); assert.throws(()=>a.enqueue(T,cid));
  await assert.rejects(a.poll(T,cid));
  assert.throws(()=>connect(a,T,'fixture-consent-customer'));
  a.enqueue(C,cid); a.disconnect(C,cid);
  const other=connect(a,C,'fixture-consent-third'); assert.notEqual(other,cid);
  const cancelled=await a.runNext(); assert.equal(cancelled.status,'cancelled');
  assert.equal((await a.poll(C,other)).length,1);
  const old=a.get(C,rid); assert.equal(old.connection_id,cid); assert.equal(old.status,'fulfilled'); assert.equal(old.manual_note,'Original account history');
  assert.equal(a.count(T),0); assert.equal(JSON.stringify(a.connections(C)).includes('credential'),false);
}));

test('held-out: invalid grants and temporary recovery are bounded and local to their connection',scenario(async(a,p)=>{
  const cid=connect(a,C,'fixture-consent-customer'); p.revoke('fixture-grant-customer');
  await assert.rejects(a.poll(C,cid),/Reconnection/); assert.equal(a.connections(C)[0].status,'reconnect');
  const fid=ownConnection(a,F); p.temporaryFailures.add('fixture-grant-founder'); const j=a.enqueue(F,fid);
  for(let n=0;n<3;n++)await assert.rejects(a.runNext(),/fetch failed/);
  const row=a.db.prepare('SELECT * FROM jobs WHERE id=?').get(j); assert.equal(row.status,'failed'); assert.equal(row.attempts,3);
  assert.equal(a.connections(F)[0].status,'usable'); p.temporaryFailures.clear();
  assert.equal((await a.poll(F,fid)).length,1); assert.equal(a.count(C),0);
}));

test('held-out: reopening preserves mappings and progress; simulator bytes were not modified',scenario(async(a,p,file)=>{
  const cid=connect(a,C,'fixture-consent-customer'),[rid]=await a.poll(C,cid); a.update(C,rid,{manual_note:'Persistent progress'});
  const actor=a.signIn(C), other=new App(file,p);
  try {assert.deepEqual(other.signIn(C),actor); assert.equal(other.get(C,rid).manual_note,'Persistent progress'); assert.equal(other.get(F,rid),null);}
  finally {other.close();}
  const hash=file=>createHash('sha256').update(readFileSync(new URL(file,import.meta.url))).digest('hex');
  assert.equal(hash('./baseline/provider-simulator.mjs'),hash('./candidate/provider-simulator.mjs'));
}));
