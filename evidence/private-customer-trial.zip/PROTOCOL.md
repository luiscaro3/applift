# Bounded independent implementation attempt

21 October 2026. The user authorized deeper work for this increment and explicitly distinguished mapping quality from implementation evidence. This protocol does not authorize live provider operations or changes to working applications.

## Materials and independence

- Frozen author-created representative personal POC: `baseline`, Git commit `7426ecfab243ba8e856639289b1931fa213af256`. It is not a naturally evolved customer application or working Scout.
- Original single-user workflow: one meaningful Node/SQLite test, passed before candidate changes.
- Initial public kit: `c6154de4fc901ac4d4f173c8f368923221a53ddb`; local source `7bb21ebd24b41760e5fc26e52f5f14e2ca276c0e`.
- Fresh implementation agent: `independent_implementation`, 6.1 sol low, no inherited conversation. Receives only the candidate, installed public skill and ordinary request. May consult official provider docs. Sibling evaluator and author artifacts are outside its permitted reading scope.
- Installation under test: candidate-local `.agents/skills/applift-specs` with the public kit's files. Explicit path loading is requested; implicit discovery/automatic activation is not being tested.
- Fixed simulator SHA-256: `EC1EA29EA2269972A6C4CBC8598F3547623657BCBFA628B4F0C81958A518E572`. Simulator cannot be edited by implementer.

The baseline supplies business decisions: private customers, proven founder keeps existing data, new customers start empty, customers connect/disconnect/reconnect their own mailbox, fulfillment/manual progress survives replay, no billing change. It also documents the fixture's SDK boundary. Those are supplied setup and business assumptions, not a claim of zero-context operation. No maintainer implementation advice is supplied.

## Claim boundary

The attempt must implement service/persistence behavior and execute it against SQLite. Session, consent and mailbox responses use local provider simulators; no real OAuth browser/session issuance, provider refresh/revocation endpoint or production account approval is tested. There is no UI/HTTP layer in the fixture. Results can establish only this local service-boundary case.

Predeclared criteria are in `EVALUATION.md`, created before dispatch and withheld from the implementer. Root will check actual operations independently after completion. The evaluator can adapt to the implementation's documented API while retaining those criteria; it must not retroactively weaken them to obtain a pass.

Record supplied business choices, additional clarifications, author engineering rescue, initial failures and repairs distinctly. If evaluation reveals a failure, preserve it before repair. A repaired/coached attempt cannot be described as an unassisted first pass. A single success supplies no comparative savings, broad compatibility, organic discovery or commercial launch certification.

## Product boundary

The product remains specifications, examples, diagrams and an instruction-only skill. Trial host code remains outside its integration path; an optional evidence archive may include the fixture, checks and protocol for inspection/reproduction. It is not runtime code consumers must install or a required schema to adopt. No live application, credential, paid service, endpoint or deployment is changed. Stop once the bounded transition passes its relevant checks without maintainer engineering rescue; expand only for observed gaps.
