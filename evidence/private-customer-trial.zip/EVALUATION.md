# Predeclared implementation acceptance: private campaign customers

Defined before the independent agent receives the host. This document and evaluator are outside its permitted reading scope. The implementer receives only the frozen candidate, public kit snapshot and an ordinary request. Provider simulators are fixed local boundaries, not evidence of real OAuth success. No time/effort baseline comparison is claimed.

## Required behavior

1. Existing seed record IDs 1001/1002, their source links, content, manual notes and fulfilled/completion state survive conversion. The proven founder retains them; an unrelated first signup cannot claim them.
2. Verified sessions map repeatably to actors; invalid/altered fixture sessions cannot access private service operations. New customers start empty.
3. List, detail, search, count and updates enforce the same ownership. Cross-customer IDs and forged payload context do not bypass it. This evaluates service boundaries, not an absent browser or HTTP UI.
4. Founder and second customer can connect/use their own mailbox. The same source ID in different mailboxes stays separate. Repeated import converges without duplicate requisitions.
5. Updating imported subject/body does not reset fulfillment, completion time or manual notes. A retry after database commit but before job acknowledgement preserves the same result.
6. Existing seed polling work is assigned to the proven founder; new customer jobs resolve their own authority without founder-credential fallback. Ownership remains resolvable through processing and the search projection.
7. One customer cannot disconnect, reconnect or use another customer's connection. Same-account reconnection preserves existing record identity. A different-account replacement cannot relabel old records or permit old results to commit under the replacement.
8. Revoked grant exposes reconnection-required behavior for only that connection. Temporary failure does not become permanent disconnection or silently succeed. A successful later retry can resume.
9. Disconnect during an in-flight provider fetch prevents that result from committing. Other customers' work remains usable. Pending work cannot resurrect a disconnected connection.
10. Existing personal fulfillment workflow still works after migration. Unsupported live provider/browser behavior is explicitly unverified.

Record ordinary business assumptions supplied up front separately from technical suggestions or corrections supplied by the author. Run resulting operations against SQLite; a plan, heading match or self-report alone is insufficient. One passing case supports only this representative fixture. If a consequential failure appears, record it before repair and decide whether the host implementation, public spec or simulator boundary caused it. Do not expand into billing or deployment.
